<INCLUDE_TYPOSCRIPT: source="FILE:EXT:jquerycolorbox/static/constants.txt">
