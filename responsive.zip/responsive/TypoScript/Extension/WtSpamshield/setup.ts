<INCLUDE_TYPOSCRIPT: source="FILE:EXT:wt_spamshield/static/settings/setup.txt">

plugin.wt_spamshield {
	enable.standardMailform = 1
}