<INCLUDE_TYPOSCRIPT: source="FILE:EXT:wt_spamshield/static/settings/constants.txt">
