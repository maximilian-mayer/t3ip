<INCLUDE_TYPOSCRIPT: source="FILE:EXT:tt_news/pi/static/ts_new/constants.txt">
