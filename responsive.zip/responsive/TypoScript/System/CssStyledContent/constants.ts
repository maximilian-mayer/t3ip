/*
The following line does not work, thus please include the static CSC template
in the template record.
*/
# <INCLUDE_TYPOSCRIPT: source="FILE:EXT:css_styled_content/static/constants.txt">

# Remove targets
styles.content.links.extTarget =
