/*
The PAGE FOOTERDATA.


*/


/**
 * include external js files before closing body tag
 */

page.footerData {
    #201 = TEXT
    #201.dataWrap = <script src="{$filepaths.scripts}vendor/jquery-1.8.3.min.js">|</script>
    202 = TEXT
    202.dataWrap = <script defer src="{$filepaths.scripts}main.js">|</script>
}


